from django.urls import path    
from . import views

urlpatterns = [
    path('cuentas', views.cuentas, name='cuentas'),
    path('cuentas/templates/detalles_usuarios/<int:usuario_id>/', views.detalles_usuarios, name='detalles_usuarios'),
    path('registro', views.registro, name='registro'),
    path('login', views.login, name='login')
]

