from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
import re

# Formulario de creación de usuario personalizado, con restricciones de contraseña
class CustomUserCreationForm(UserCreationForm):
    def clean_password2(self):
        password = self.cleaned_data.get('password1')
        if password:
            if len(password) < 6:
                raise ValidationError("Contraseña debe tener al menos 6 caracteres.")
            if len(password) > 25:
                raise ValidationError("Contraseña debe tener como máximo 25 caracteres.")
            if not re.search('\d', password):
                raise ValidationError("Contraseña debe contener al menos un número.")
        return super().clean_password2()