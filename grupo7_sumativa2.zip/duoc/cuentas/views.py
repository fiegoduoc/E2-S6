from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from django.template import loader
from .models import Usuario
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm

## VISTA PARA MOSTRAR HTML CON LISTA DE USUARIOS REGISTRADOS ##
def cuentas(request):
    listausuarios = Usuario.objects.all().values()
    template = loader.get_template('usuarios.html')
    context = {
        'listausuarios': listausuarios,
    }
    return HttpResponse(template.render(context, request))

def detalles_usuarios(request, usuario_id):
    usuario = get_object_or_404(Usuario, pk=usuario_id)
    template = loader.get_template('detalles_usuarios.html')
    return render(request, 'detalles_usuarios.html', {'usuario': usuario})

def registro(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = CustomUserCreationForm() 
    return render(request, 'registro.html', {'form': form})

def login(request):
    return render(request, 'login.html')