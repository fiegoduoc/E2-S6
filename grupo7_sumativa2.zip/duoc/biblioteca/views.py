from django.shortcuts import render

# Create your views here.
def index(request):
    contexto = {
        'saludo' : '👍 bienvenido' 
    }
    return render(request, 'index.html', contexto)

def categorias(request):
    return render(request, 'categorias.html')

def contacto(request):
    return render(request, 'contacto.html')

def hiphop(request):
    return render(request, 'hiphop.html')

def pop(request):
    return render(request, 'pop.html')

def pop(request):
    return render(request, 'pop.html')

def rock(request):
    return render(request, 'rock.html')