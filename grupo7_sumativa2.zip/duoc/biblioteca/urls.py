from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('categorias', views.categorias, name="categorias"),
    path('index/contacto', views.contacto, name="contacto"),
    path('categorias/hiphop', views.hiphop, name="hiphop"),
    path('categorias/pop', views.pop, name="pop"),
    path('categorias/rock', views.rock, name="rock")
    #path('index/registro', views.registro, name="registro") 
]